New Journey Global Consulting - One Page (Version LUXE) - FR

Contenu du ZIP:
- index.html
- assets/logo.png

Mise en ligne (rapide):
Option A) Netlify:
1) Créez un compte Netlify
2) Glissez-déposez ce ZIP (ou le dossier)
3) Le site est en ligne
4) Connectez ensuite le domaine newjourneyglobalconsulting.com

Option B) Hébergeur (Hostinger/OVH/Namecheap):
1) Uploadez index.html + le dossier assets/ dans public_html
2) Vérifiez que assets/logo.png existe bien

WhatsApp:
Le bouton WhatsApp est configuré sur +216 54 101 100.

Réseaux sociaux:
- Facebook: https://www.facebook.com/newjourneyglobalconsul
- Instagram: https://www.instagram.com/new_journey_global_consulting/

Contacts:
- +216 54 101 100
- +216 55 629 627

Mise à jour: sections FAQ et Avis supprimées.

Mise à jour PRO:
- Palette alignée sur le logo (bleu marine + rouge)
- Polices pro (Inter + Sora)
- Icônes SVG professionnelles
- Images (étudiants + drapeaux) dans la section Destinations


=== Mode édition (Decap CMS) ===
1) Mettez ce site dans un repo GitHub, puis connectez-le à Netlify (deploy depuis Git).
2) Dans Netlify: Site configuration > Identity: Enable Identity, puis Services > Git Gateway: Enable.
3) Ouvrez: https://VOTRE-DOMAINE/admin/ pour modifier textes/images.
Notes: la config CMS est dans /admin/config.yml et les contenus dans /content/site.json.
